copy "controller" folder to /etc/iofabric/
